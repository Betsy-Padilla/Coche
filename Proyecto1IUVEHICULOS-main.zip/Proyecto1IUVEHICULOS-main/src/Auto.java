public class Auto extends Vehiculo {
    public Auto(String codigo, String marca, int modelo, int kilometraje, double monto) {
        super(codigo, marca, "Auto", modelo, kilometraje, monto);
    }
}