public class Camioneta extends Vehiculo {
    public Camioneta(String codigo, String marca, int modelo, int kilometraje, double monto) {
        super(codigo, marca, "Camioneta", modelo, kilometraje, monto);
    }
}