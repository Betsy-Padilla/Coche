public class Motocicleta extends Vehiculo {
    public Motocicleta(String codigo, String marca, int modelo, int kilometraje, double monto) {
        super(codigo, marca, "Motocicleta", modelo, kilometraje, monto);
    }
}